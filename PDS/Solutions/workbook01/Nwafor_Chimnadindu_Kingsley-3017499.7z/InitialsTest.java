//Nwafor Chimnadindu Kingsley 3017499
package workbook01;

import workbook01.Initials;
public class InitialsTest {
	public static void main(String[] args) {

		// Another instance of Initials
		Initials Kingsley = new Initials();

		// test for final initials
		Kingsley.initials();

	}
}
