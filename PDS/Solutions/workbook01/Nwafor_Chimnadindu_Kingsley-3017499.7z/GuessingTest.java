//Nwafor Chimnadindu Kingsley 3017499
package workbook01;

import workbook01.Guessing;
public class GuessingTest {	
	//Declare game as a string
	String game;
	//Main method
	public static void main(String[] args) {
		Guessing game = new Guessing();			
		game.Guessing();
			
	}

}
