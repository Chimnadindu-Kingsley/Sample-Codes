//Nwafor Chimnadindu Kingsley 3017499
package Assignment_5;

public interface PRSI {

	// 4%
	static final double rate = 0.04;

	// method to calculate PRSI
	public abstract double calculatePRSI();

}
