//Nwafor Chimnadindu Kingsley 3017499
package Assignment_5;

public interface Taxable {

	// abstract method to calculate tax
	public abstract double calculateTax();

	// abstract method to print tax
	public abstract void printTax();

}
